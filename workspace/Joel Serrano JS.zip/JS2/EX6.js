var meses=['Enero','Febrero','Marzo','Abril','Mayo','Junio',
'Julio','Agosto','Setiembre','Octubre','Noviembre','Diciembre'];
alert(meses);