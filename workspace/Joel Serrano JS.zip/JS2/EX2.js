for (var i = 1; i <= 6; i++) {
    document.write("<h" + i + ">Javascript</h" + i + ">");
}