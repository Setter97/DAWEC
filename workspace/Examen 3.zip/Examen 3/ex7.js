var usr=prompt("Introduce un angulo entre 0 y 360");
var angulo=parseInt(usr);
document.write("Seno "+Math.sin(angulo)+"<br> Coseno "+Math.cos(angulo)+"<br> Tangente "+Math.tan(angulo));